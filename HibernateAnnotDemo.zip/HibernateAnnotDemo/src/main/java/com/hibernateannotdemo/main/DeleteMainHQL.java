package com.hibernateannotdemo.main;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.hibernate.service.ServiceRegistry;

import com.hibernateannotdemo.pojo.Product;

public class DeleteMainHQL {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		Configuration config = new Configuration();
		config.configure();
		
		SessionFactory sf = config.buildSessionFactory();
		
		Session s = sf.openSession();
		
		System.out.print("Enter id of the product "
				+ "to be deleted : ");
		int pid = sc.nextInt();
		
		Transaction tr = s.beginTransaction();
		
		Query q = s.createQuery("DELETE FROM Product p"
				+ " WHERE p.pid = :id");
		q.setParameter("id", pid);
		
		int count = q.executeUpdate();
		tr.commit();
		
		if(count > 0)
			System.out.println("product deleted");
		else
			System.out.println("no such product found");
		
		sf.close();
	}
}




