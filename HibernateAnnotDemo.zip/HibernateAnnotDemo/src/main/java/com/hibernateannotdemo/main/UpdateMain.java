package com.hibernateannotdemo.main;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.hibernateannotdemo.pojo.Product;

public class UpdateMain {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		Configuration config = new Configuration();
		config.configure();
		
		SessionFactory sf = config.buildSessionFactory();
		
		Session s = sf.openSession();
		
		System.out.print("Enter id of the product "
				+ "to be updated : ");
		int pid = sc.nextInt();
		
		Product product = s.get(Product.class, pid);
		
		if(product != null) {
			
			Transaction tr = s.beginTransaction();
			
			System.out.print("Enter new price of "
					+ "the product : ");
			int prc = sc.nextInt();
			System.out.print("Enter new name of "
					+ "the product : ");
			String nm = sc.next();
			
			product.setPname(nm);
			product.setPrice(prc);
			s.update(product);
			tr.commit();
			System.out.println("product updated");
		}
		else
			System.out.println("no such product found");
		
		sf.close();
	}
}




