package com.hibernateannotdemo.main;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.hibernate.service.ServiceRegistry;

import com.hibernateannotdemo.pojo.Product;

public class SearchMainCriteria {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		Configuration config = new Configuration();
		config.configure();
		
		SessionFactory sf = config.buildSessionFactory();
		
		Session s = sf.openSession();
		
		System.out.print("Enter id of the product "
				+ "to be searched : ");
		int p_id = sc.nextInt();
		
		Criteria cr = s.createCriteria(Product.class);
		
		cr.add(Restrictions.eq("pid", p_id));
		
		List<Product> lst = cr.list();
		
		if(lst.size() > 0) 
			System.out.println(lst.get(0));
		else 
			System.out.println("no such product found");
		
		sf.close();
	}
}




