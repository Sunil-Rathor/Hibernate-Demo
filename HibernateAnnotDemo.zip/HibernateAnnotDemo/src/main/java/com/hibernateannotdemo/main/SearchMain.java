package com.hibernateannotdemo.main;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.hibernateannotdemo.pojo.Product;

public class SearchMain {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		Configuration config = new Configuration();
		config.configure();
		
		SessionFactory sf = config.buildSessionFactory();
		
		Session s = sf.openSession();
		
		System.out.print("Enter id of the product "
				+ "to be searched : ");
		int pid = sc.nextInt();
		
		Product product = s.get(Product.class, pid);
		
		//Product product = s.load(Product.class, pid);
		
		if(product != null)
			System.out.println(product);
		else
			System.out.println("no such product found");
		
		sf.close();
	}
}




