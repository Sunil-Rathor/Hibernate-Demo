package com.hibernateannotdemo.main;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.hibernate.service.ServiceRegistry;

import com.hibernateannotdemo.pojo.Product;

public class UpdateMainHQL {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		Configuration config = new Configuration();
		config.configure();
		
		SessionFactory sf = config.buildSessionFactory();
		
		Session s = sf.openSession();
		
		System.out.print("Enter id of the product "
				+ "to be updated : ");
		int pid = sc.nextInt();
		
		Transaction tr = s.beginTransaction();
		
		Query q = s.createQuery("UPDATE Product p"
				+ " SET p.pname = :nm , p.price = :prc"
				+ " WHERE p.pid = :id");
		
		System.out.print("Enter new name of the"
				+ " product : ");
		String pname = sc.next();
		System.out.print("Enter new price of the"
				+ " product : ");
		int prc = sc.nextInt();
		
		q.setParameter("nm", pname);
		q.setParameter("prc", prc);
		q.setParameter("id", pid);
		
		int count = q.executeUpdate();
		tr.commit();
		
		if(count > 0)
			System.out.println("product updated");
		else
			System.out.println("no such product found");
		
		sf.close();
	}
}




